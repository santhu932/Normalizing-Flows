1. Run all the blocks of "Task 1" notebook for the results of Task 1
2. Run all the blocks of "Task 2" notebook for the results of Task 2 and Extra Credits Part